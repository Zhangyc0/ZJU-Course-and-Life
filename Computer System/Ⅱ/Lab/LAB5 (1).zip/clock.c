//clock.c
#include "defs.h"
#include "riscv.h"
volatile unsigned long long ticks;
static uint64_t TIMECLOCK = 10000000; 

const uint64_t SBI_SET_TIMER = 0;

extern sbi_call();
uint64_t get_cycles(void)
{
#if __riscv_xlen == 64
    uint64_t n;
    __asm__ __volatile__("rdtime %0"
                         : "=r"(n));
    return n;
#else
    uint32_t lo, hi, tmp;
    __asm__ __volatile__(
        "1:\n"
        "rdtimeh %0\n"
        "rdtime %1\n"
        "rdtimeh %2\n"
        "bne %0, %2, 1b"
        : "=&r"(hi), "=&r"(lo), "=&r"(tmp));
    return ((uint64_t)hi << 32) | lo;
#endif
}

void clock_set_next_event(void)
{
        puts("LAB5\n");
    __asm__ __volatile__(
        "li t1,32\n"
        "csrrs x0,sie,t1\n" ::
            :);

    unsigned long cs = read_csr(sie);

    uint64_t nextTime = get_cycles() + TIMECLOCK;
    trigger_time_interrupt(nextTime);
    uint64_t nextTime = get_cycles() + TIMECLOCK;
    trigger_time_interrupt(nextTime);
}
