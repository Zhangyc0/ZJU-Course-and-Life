//proc.c
#include "proc.h"
#include "puts.h"
#include "rand.h"

extern void __dummy();
extern void __switch_to(struct task_struct* prev, struct task_struct* next);

struct task_struct* idle;          
struct task_struct* current;        
struct task_struct* task[NR_TASKS]; 
void dummy() {
    uint64 MOD = 1000000007;
    uint64 auto_inc_local_var = 0;
    int last_counter = -1;
    while(1) {
        if (last_counter == -1 || current->counter != last_counter) {
            last_counter = current->counter;
            auto_inc_local_var = (auto_inc_local_var + 1) % MOD;
            printk("[PID = %d] is running. auto_inc_local_var = %d\n", current->pid, auto_inc_local_var); 
        }
    }
}
#define LAB_TEST_NUM 32;
void task_init() {
    current = (struct task_struct *)TASK_BASE;
    idle = (struct task_struct*)kalloc();
    idle -> state = TASK_RUNNING;
    idle -> counter = 0;
    idle -> priority = 0;
    idle -> pid = 0;
    current = idle;
    task[0] = idle;
    for (int i = 0; i <= LAB_TEST_NUM; i++) {
       unsigned long ret;
    ret = kalloc();
    task[i] = ret;
    task[i] -> state = TASK_RUNNING;
    task[i] -> counter = 0;
    task[i] -> priority = rand();
    task[i] -> pid = i;
    task[i] -> thread.ra = &__dummy;
    task[i] -> thread.sp = ret + PGSIZE;
        if (i != 0) {
            puts("[PID = ");
            puti(task[i]->pid);
            puts("] Process Create Successfully! counter = ");
            puti(task[i]->counter);
#ifdef  PRIORITY
            puts(" priority = ");
            puti(task[i]->priority);
#endif
            puts("\n");
        }
    }
}

void do_timer() {
#ifdef  PRIORITY  
    puts("[PID = ");
    puti(current->pid);
    puts("] ");
    puts("Context Calculation: ");
    puts("counter = ");
    puti(current->counter);
    puts("\n");

    current->counter--;
    if (current->counter <= 0)
        schedule();

#else  
    current->counter--;
    if (current->counter <= 0)
        current->counter = (current->pid == 0) ? 5 : 8 - current->pid;
    schedule();
#endif
}

void switch_to(struct task_struct *next) {
    if (current == next)
        return;
   else
   {
    printk("\n switch to [PID = %d COUNTER = %d] \n", next->pid, next->counter);
    __switch_to(current, next);
    }
    asm("addi sp, sp, 32"); 
    CONTEXT_SAVE(current);   
    current = next;         
    CONTEXT_LOAD(current);   
    asm("ret");
}


void schedule() {
#ifdef SJF         
    int i_min_cnt    = LAB_TEST_NUM;  
    _Bool all_zeroes = 1;
    for (int i = LAB_TEST_NUM; i > 0; i--)
        if (task[i]->state == TASK_RUNNING) {
            if (task[i]->counter > 0 && task[i]->counter < task[i_min_cnt]->counter ||
                task[i_min_cnt]->counter == 0)
                i_min_cnt = i;
            if (task[i]->counter > 0)  
                all_zeroes = 0;
        }
    if (all_zeroes) {
        for (int i = 1; i <= LAB_TEST_NUM; i++)
            if (task[i]->state == TASK_RUNNING) {
                task[i]->counter = rand();

                puts("[PID = ");
                puti(task[i]->pid);
                puts("] Reset counter = ");
                puti(task[i]->counter);
                puts("\n");
            }
        schedule();
    } else {
        puts("[!] Switch from task ");
        puti(current->pid);
        puts(" to task ");
        puti(task[i_min_cnt]->pid);
        puts(", prio: ");
        puti(task[i_min_cnt]->priority);
        puts(", counter: ");
        puti(task[i_min_cnt]->counter);
        puts("\n");

        switch_to(task[i_min_cnt]);
    }

#else 
    int max_pri = __INT_MAX__, i_min_cnt = 1;
    for (int i = 1; i <= LAB_TEST_NUM; i++)
        if (task[i]->state == TASK_RUNNING)
            if (task[i]->priority < max_pri) {
                i_min_cnt = i;
                max_pri   = task[i]->priority;
            } else if (task[i]->priority == max_pri &&
                       task[i]->counter < task[i_min_cnt]->counter && task[i]->counter > 0)
                i_min_cnt = i;

    puts("[!] Switch from task ");
    puti(current->pid);
    puts(" to task ");
    puti(task[i_min_cnt]->pid);
    puts(", prio: ");
    puti(task[i_min_cnt]->priority);
    puts(", counter: ");
    puti(task[i_min_cnt]->counter);
    puts("\n");

    for (int i = 1; i <= LAB_TEST_NUM; i++)
        if (task[i]->state == TASK_RUNNING)
            task[i]->priority = rand();

    puts("tasks' priority changed\n");
    for (int i = 1; i <= LAB_TEST_NUM; i++)
        if (task[i]->state == TASK_RUNNING) {
            puts("[PID = ");
            puti(task[i]->pid);
            puts("] ");
            puts("counter = ");
            puti(task[i]->counter);
            puts(" priority = ");
            puti(task[i]->priority);
            puts("\n");
        }
    switch_to(task[i_min_cnt]);
#endif
}
#define PHY_START 0x0000000080000000
#define PHY_SIZE  128 * 1024 * 1024 // 128MB， QEMU 默认内存大小 
#define PHY_END   (PHY_START + PHY_SIZE)

#define PGSIZE 0x1000 // 4KB
#define PGROUNDUP(addr) ((addr + PGSIZE - 1) & (~(PGSIZE - 1)))
#define PGROUNDDOWN(addr) (addr & (~(PGSIZE - 1)))