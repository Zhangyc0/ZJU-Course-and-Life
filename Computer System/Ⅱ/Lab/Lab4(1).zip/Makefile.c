all: main

main: print.c 
	${CC} ${CFLAG}  -c $^


clean:
	$(shell rm *.o 2>/dev/null)