#include "print.h"
#include "sbi.h"

void puts(char *s) {
   	do{
		sbi_call(1, (uint64_t)*s, 0, 0);
		s = s + 1;	
	}while (*s != '\0');

	return 0;
}

void puti(int x) {
	char str[100];
	char ustr[100];
	int m;
	int i = 0;
	int j = 0;
	do{
		m = n%10;
		n = n/10;
		ustr[i] = '0'+m;
		i++; 
	}while (x != 0);
	for (i = i - 1; i >= 0; i--){
		str[j] = ustr[i];
		j++;
	}
	str[j] = '\0';
	puts(str);
	return 0;
	}
