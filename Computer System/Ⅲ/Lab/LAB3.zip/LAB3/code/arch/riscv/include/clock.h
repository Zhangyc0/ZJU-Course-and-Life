void clock_set_next_event();
unsigned long get_cycles();