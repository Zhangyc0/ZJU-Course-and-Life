void test() {
    while (1){
        
    };
}
